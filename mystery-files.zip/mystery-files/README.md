# MYSTERY FILES - CASE 001: THE ROOM THAT WAS NEVER OPENED

TikTok cinematic mystery, built with React + Remotion + TypeScript.
**Fictional entertainment** - labelled on screen throughout ("قصة خيالية").

| Spec | Value |
|---|---|
| Composition id | `MysteryFilesCase001` |
| Size | 1080 x 1920 (9:16) |
| Frame rate / length | 30 fps / 900 frames = exactly 30 s |
| Codec | H.264 (yuv420p), CRF 16, AAC audio, 48 kHz |
| Output | `dist/Mystery_Files_Case_001.mp4` |

## Run it

```bash
npm install          # first time (Node 18+)
npm run dev          # Remotion Studio - scrub the timeline, preview audio
npm run build        # typecheck + render -> dist/Mystery_Files_Case_001.mp4
npm run render       # render only
npm run poster       # still frame (end card) -> dist/poster.png
npm run audio        # regenerate placeholder audio (needs bash + ffmpeg)
```

Fonts (Cairo, Orbitron) are fetched from Google Fonts by `@remotion/google-fonts` on first render, so the machine needs internet access then. Offline? Drop the font files in `public/fonts/` and swap the `loadFont` calls in `src/styles/theme.ts` for `staticFile` + `@font-face`.

Expect a slow render (film grain, blur and blend modes are heavy): 20-60 min on a laptop is normal. Add `--concurrency=<n>` to tune it.

## Timeline

| Scene | Frames | Time | Beat |
|---|---|---|---|
| 01 Hook | 0-89 | 0-3 s | Black, metal impact (f3), door emerges, red strobe, "غرفة مغلقة... / ورجل اختفى!" |
| 02 Mystery | 90-239 | 3-8 s | Corridor, plate 317, locks, sealed window; hard cuts at f130/158/190 |
| 03 Investigation | 240-419 | 8-14 s | Evidence board, strings draw in, "لا أحد دخل... / ولا أحد خرج..." |
| 04 Twist | 420-629 | 14-21 s | Clock races to 03:17 (hit f495), phone rings f500-598, **silence f598-630** |
| 05 Reveal | 630-779 | 21-26 s | Impact f630, call-log LCD, zoom on FROM: EXT. 317, ANSWERED f748 |
| 06 Final hook | 780-899 | 26-30 s | Silhouette behind frosted glass, closing question, end card, fade to red slit |

The last frame (black + thin red light slit) matches frame 0, so the video loops seamlessly.

## Sound

All cues live in one cue sheet: `src/audioCues.ts` (global frame numbers). The files in `public/audio/` are **original synthesised placeholders** (ffmpeg, royalty-free): `ambient`, `impact`, `metal`, `phone_ring`, `tick`, `whoosh_rev`, `static`, `footsteps`. To upgrade the mix, replace any file with your own asset of the **same filename**; no code changes needed.

## Arabic

Text is `dir="rtl" lang="ar"`, Cairo 900. Animation is per **word**, never per letter, because splitting Arabic into letters breaks joining. No letter-spacing is applied to Arabic.

## Structure

```
src/index.ts, Root.tsx, MysteryEpisode.tsx, audioCues.ts
src/scenes/Scene01-06.tsx
src/components/ CinematicText, EvidenceBoard, DigitalClock, HotelDoor, Telephone, FilmGrain, Particles, Overlays
src/styles/theme.ts
public/audio/*.wav     scripts/make-audio.sh
```

## Publish

**Caption**
غرفة مغلقة من الداخل... ورجل اختفى 🕵️‍♂️
في الساعة 3:17 فجراً رنّ هاتف الغرفة، والمكالمة جاءت من داخلها!
إذا لم يكن هناك أحد... فمن الذي ردّ؟ 👁️ اكتب توقعك في التعليقات!
(قصة خيالية - MYSTERY FILES | CASE 001)

**Hashtags:** #MysteryFiles #غموض #ألغاز #قصة_غامضة #تشويق

**SEO filename for upload:** `mystery-files-case-001-the-room-that-was-never-opened-hotel-room-317-arabic-mystery-story.mp4`
