import {Easing, interpolate} from 'remotion';
import {loadFont as loadCairo} from '@remotion/google-fonts/Cairo';
import {loadFont as loadOrbitron} from '@remotion/google-fonts/Orbitron';

// Cairo ExtraBold/Black: bold Arabic face with full joining/shaping support.
const cairo = loadCairo('normal', {weights: ['800', '900'], subsets: ['arabic', 'latin']});
const orbitron = loadOrbitron('normal', {weights: ['700', '900'], subsets: ['latin']});

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const TOTAL = 900; // 30 s * 30 fps

// Scene timeline (frames). Sum of durations = 900.
export const SCENES = {
  s1: {from: 0, dur: 90}, //   00-03 s  The Hook
  s2: {from: 90, dur: 150}, // 03-08 s  The Mystery
  s3: {from: 240, dur: 180}, // 08-14 s  The Investigation
  s4: {from: 420, dur: 210}, // 14-21 s  The Twist
  s5: {from: 630, dur: 150}, // 21-26 s  The Reveal
  s6: {from: 780, dur: 120}, // 26-30 s  The Final Hook
} as const;

export const colors = {
  black: '#050507',
  charcoal: '#0e1015',
  steel: '#2a3340',
  cold: '#6fa8dc',
  ice: '#cfe6ff',
  crimson: '#8f0f1c',
  red: '#e11d2e',
  bone: '#ece7da',
};

export const fonts = {
  arabic: `${cairo.fontFamily}, 'IBM Plex Sans Arabic', 'Noto Sans Arabic', Tahoma, sans-serif`,
  digital: `${orbitron.fontFamily}, 'Courier New', monospace`,
  mono: `'Courier New', ui-monospace, monospace`,
};

// TikTok-safe text zone: keeps captions clear of the bottom UI (y > ~1520).
export const TEXT_Y = 1130;

export const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
export const easeInOut = Easing.bezier(0.65, 0, 0.35, 1);

/** Deterministic pseudo-random in [0,1). Same input -> same output (render-safe). */
export const hash = (n: number): number => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

/** Clamped interpolation helper. Requires from < to. */
export const ramp = (
  frame: number,
  from: number,
  to: number,
  a: number,
  b: number,
  easing?: (t: number) => number
): number =>
  interpolate(frame, [from, to], [a, b], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing,
  });
