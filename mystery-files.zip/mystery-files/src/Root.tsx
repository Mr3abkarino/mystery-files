import React from 'react';
import {Composition} from 'remotion';
import {MysteryEpisode} from './MysteryEpisode';
import {FPS, H, TOTAL, W} from './styles/theme';

export const Root: React.FC = () => (
  <Composition
    id="MysteryFilesCase001"
    component={MysteryEpisode}
    durationInFrames={TOTAL} // 900 frames = 30 s @ 30 fps
    fps={FPS}
    width={W} // 1080
    height={H} // 1920  (9:16)
  />
);
