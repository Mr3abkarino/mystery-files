import {ramp} from './styles/theme';

/**
 * AUDIO CUE SHEET - the single place where sound is synchronised to picture.
 * `from` is a GLOBAL frame (30 fps). Every file lives in public/audio/ and can be swapped for
 * your own asset of the same name (run `npm run audio` to regenerate the synthesised placeholders).
 * `volume` is a number or a function of the cue-local frame.
 */
export type Cue = {
  id: string;
  file: string;
  from: number;
  durationInFrames?: number; // default: until the end of the video
  volume: number | ((localFrame: number) => number);
  fadeIn?: number;
  fadeOut?: number;
  loop?: boolean;
};

// Ambient bed: silent between frames 598-630 (the dramatic silence before the reveal), swells back after the impact.
const ambientVolume = (f: number): number => {
  const gate = f < 580 ? 1 : f < 598 ? ramp(f, 580, 598, 1, 0) : f < 630 ? 0 : ramp(f, 630, 700, 0.35, 1);
  return 0.5 * ramp(f, 0, 24, 0, 1) * gate * ramp(f, 850, 899, 1, 0.05);
};

export const CUES: Cue[] = [
  // Scene 01 - hook
  {id: 'ambient', file: 'ambient.wav', from: 0, volume: ambientVolume},
  {id: 'door-clang', file: 'metal.wav', from: 3, durationInFrames: 60, volume: 0.8},
  {id: 'door-impact', file: 'impact.wav', from: 3, durationInFrames: 105, volume: 1},
  {id: 'whoosh-1', file: 'whoosh_rev.wav', from: 48, durationInFrames: 45, volume: 0.55},
  // Scene 02 - corridor, cuts at 130 / 158 / 190
  {id: 'footsteps', file: 'footsteps.wav', from: 100, durationInFrames: 140, volume: 0.5, fadeOut: 20},
  {id: 'cut-static-a', file: 'static.wav', from: 130, durationInFrames: 6, volume: 0.45},
  {id: 'cut-static-b', file: 'static.wav', from: 158, durationInFrames: 6, volume: 0.45},
  {id: 'cut-static-c', file: 'static.wav', from: 190, durationInFrames: 6, volume: 0.45},
  {id: 'whoosh-2', file: 'whoosh_rev.wav', from: 200, durationInFrames: 45, volume: 0.5},
  // Scene 03 - evidence board
  {id: 'board-hit', file: 'impact.wav', from: 240, durationInFrames: 60, volume: 0.6},
  {id: 'cctv-static', file: 'static.wav', from: 240, durationInFrames: 180, volume: 0.1, fadeIn: 15, fadeOut: 20, loop: true},
  // Scene 04 - twist: clock ticks 420-498, 03:17 hit at 495, phone rings 500-598, SILENCE 598-630
  {id: 'clock-tick', file: 'tick.wav', from: 420, durationInFrames: 78, volume: 0.6},
  {id: 'twist-impact', file: 'impact.wav', from: 495, durationInFrames: 100, volume: 0.9},
  {id: 'phone-ring', file: 'phone_ring.wav', from: 500, durationInFrames: 98, volume: 0.85},
  // Scene 05 - reveal
  {id: 'reveal-impact', file: 'impact.wav', from: 630, durationInFrames: 105, volume: 1},
  {id: 'reveal-static', file: 'static.wav', from: 630, durationInFrames: 8, volume: 0.5},
  {id: 'answered-hit', file: 'metal.wav', from: 748, durationInFrames: 30, volume: 0.5},
  // Scene 06 - final hook
  {id: 'distant-ring', file: 'phone_ring.wav', from: 800, durationInFrames: 60, volume: 0.18, fadeOut: 15},
  {id: 'final-sting', file: 'impact.wav', from: 862, durationInFrames: 38, volume: 0.9, fadeOut: 12},
];
