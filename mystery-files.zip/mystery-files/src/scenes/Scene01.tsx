import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {HotelDoor} from '../components/HotelDoor';
import {CinematicText} from '../components/CinematicText';
import {Fog, Particles} from '../components/Particles';
import {Flash, LightSlit, StaticBurst} from '../components/Overlays';
import {colors, easeInOut, hash, ramp, TEXT_Y, W} from '../styles/theme';

/** SCENE 01 - THE HOOK (0-3 s). Black, metallic impact, door emerges, red emergency strobe. */
export const Scene01: React.FC = () => {
  const frame = useCurrentFrame();
  const doorOp = ramp(frame, 5, 45, 0, 1);
  const push = ramp(frame, 0, 90, 1, 1.38, easeInOut);
  const strobe = frame < 10 ? 0 : Math.pow(Math.max(0, Math.sin(frame * 0.5)), 3);
  const shakeAmt = frame >= 4 && frame < 18 ? ramp(frame, 4, 18, 28, 0) : 0;
  const sx = (hash(frame * 1.9) - 0.5) * shakeAmt;
  const sy = (hash(frame * 2.7) - 0.5) * shakeAmt;
  const doorW = 780;

  return (
    <AbsoluteFill style={{backgroundColor: colors.black}}>
      <AbsoluteFill style={{transform: `translate(${sx}px, ${sy}px) scale(${push})`, transformOrigin: '50% 48%'}}>
        <div style={{position: 'absolute', left: (W - doorW) / 2, top: 90, opacity: doorOp}}>
          <HotelDoor width={doorW} redLight={0.35 + 0.65 * strobe} glow={0.3 + 0.7 * strobe} lockProgress={1} />
        </div>
      </AbsoluteFill>

      <AbsoluteFill
        style={{
          mixBlendMode: 'screen',
          background: `radial-gradient(ellipse at 50% 8%, rgba(225,29,46,${0.55 * strobe}) 0%, rgba(225,29,46,0) 60%)`,
        }}
      />
      <Fog color="rgba(70,110,170,0.35)" opacity={0.55 * doorOp} />
      <Particles count={50} opacity={0.5 * doorOp} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(5,5,7,0) 55%, rgba(5,5,7,0.92) 78%)'}} />

      <CinematicText
        top={TEXT_Y}
        lines={[
          {text: 'غرفة مغلقة...', start: 22, size: 140, glitch: true},
          {text: 'ورجل اختفى!', start: 46, size: 160, color: '#ff4150', glow: 'rgba(225,29,46,0.8)', glitch: true},
        ]}
      />

      <Flash at={4} len={8} color="#cfe6ff" peak={0.9} />
      <StaticBurst at={84} len={4} />
      {/* same red slit as the final frame of Scene 06 -> seamless loop */}
      <LightSlit opacity={ramp(frame, 0, 10, 0.85, 0)} />
    </AbsoluteFill>
  );
};
