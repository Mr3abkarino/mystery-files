import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {EvidenceBoard} from '../components/EvidenceBoard';
import {CinematicText} from '../components/CinematicText';
import {Fog, Particles} from '../components/Particles';
import {FilmBurn, LightSweep, StaticBurst} from '../components/Overlays';
import {colors, ramp} from '../styles/theme';

/** SCENE 03 - THE INVESTIGATION (8-14 s). Evidence board, red strings, slow push-in. */
export const Scene03: React.FC = () => {
  const frame = useCurrentFrame();
  const scale = ramp(frame, 0, 180, 1.0, 1.14);
  const rot = ramp(frame, 0, 180, -0.6, 0.6);
  return (
    <AbsoluteFill style={{backgroundColor: colors.black}}>
      <AbsoluteFill style={{transform: `scale(${scale}) rotate(${rot}deg)`, transformOrigin: '50% 40%'}}>
        <EvidenceBoard />
      </AbsoluteFill>
      <AbsoluteFill style={{background: `linear-gradient(180deg, rgba(5,5,7,0) 50%, ${colors.black} 68%)`}} />
      <Fog color="rgba(70,110,170,0.25)" opacity={0.5} />
      <Particles count={55} opacity={0.5} seed={9} />
      <CinematicText
        top={1150}
        lines={[
          {text: 'لا أحد دخل...', start: 36, size: 130},
          {text: 'ولا أحد خرج...', start: 96, size: 130, color: '#ff4150', glow: 'rgba(225,29,46,0.8)', glitch: true},
        ]}
      />
      <LightSweep start={20} dur={50} />
      <FilmBurn at={0} len={16} peak={0.7} />
      <StaticBurst at={0} len={3} />
    </AbsoluteFill>
  );
};
