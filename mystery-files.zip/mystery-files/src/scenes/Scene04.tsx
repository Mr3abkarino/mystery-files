import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Telephone} from '../components/Telephone';
import {DigitalClock} from '../components/DigitalClock';
import {CinematicText} from '../components/CinematicText';
import {Fog, Particles} from '../components/Particles';
import {Flash, LightSweep} from '../components/Overlays';
import {colors, easeInOut, hash, ramp, W} from '../styles/theme';

const RING_START = 80;
const RING_END = 178; // phone cuts out here -> 1 s of silence before the reveal

/** SCENE 04 - THE TWIST (14-21 s). Clock races to 03:17, phone rings, abrupt silence. */
export const Scene04: React.FC = () => {
  const frame = useCurrentFrame();
  const ringing = frame >= RING_START && frame < RING_END;
  const push = ramp(frame, 0, 210, 1, 1.22, easeInOut);
  const sx = ringing ? (hash(frame * 1.3) - 0.5) * 14 : 0;
  const sy = ringing ? (hash(frame * 2.1) - 0.5) * 14 : 0;
  const clockOp = ramp(frame, 8, 22, 0, 1);
  const dim = ramp(frame, RING_END, 202, 0, 0.75);
  const toBlack = ramp(frame, 200, 210, 0, 1);
  const glow = ringing ? 0.35 + 0.35 * Math.sin(frame * 1.1) : 0.06;

  return (
    <AbsoluteFill style={{backgroundColor: colors.black}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 30% 20%, #16263a 0%, #07090d 60%, #020304 100%)'}} />
      <div
        style={{
          position: 'absolute',
          left: -200,
          top: -120,
          width: 900,
          height: 1500,
          background: 'linear-gradient(115deg, rgba(110,160,230,0.28), rgba(110,160,230,0) 60%)',
          filter: 'blur(30px)',
          transform: 'rotate(-12deg)',
        }}
      />

      <div style={{position: 'absolute', left: 0, width: W, top: 190, display: 'flex', justifyContent: 'center', opacity: clockOp}}>
        <DigitalClock from={177} to={197} start={15} end={75} scale={0.9} />
      </div>

      <div
        style={{
          position: 'absolute',
          left: (W - 1400) / 2,
          top: 430,
          transform: `translate(${sx}px, ${sy}px) scale(${push})`,
          transformOrigin: '50% 50%',
        }}
      >
        <Telephone width={1400} ring={ringing ? 1 : 0} redGlow={glow} />
      </div>

      {/* expanding ring waves while the phone rings */}
      {ringing ? (
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          {[0, 1, 2].map((k) => {
            const p = (((frame - RING_START) * 1.5 + k * 20) % 60) / 60;
            return <circle key={k} cx={540} cy={880} r={150 + p * 520} fill="none" stroke={colors.red} strokeWidth={6} opacity={(1 - p) * 0.5} />;
          })}
        </svg>
      ) : null}

      <Fog color="rgba(70,110,170,0.3)" opacity={0.5} />
      <Particles count={55} opacity={0.55} seed={21} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(5,5,7,0) 52%, rgba(5,5,7,0.88) 74%)'}} />

      <CinematicText
        top={1170}
        lines={[
          {text: 'لكن في الساعة 3:17 فجراً...', start: 28, size: 78},
          {text: 'رنّ هاتف الغرفة!', start: 100, size: 140, color: '#ff4150', glow: 'rgba(225,29,46,0.85)', glitch: true},
        ]}
      />

      <LightSweep start={70} dur={35} color="rgba(255,90,100,0.5)" />
      <Flash at={75} len={10} color="#e11d2e" peak={0.5} />
      <AbsoluteFill style={{background: `rgba(0,0,0,${dim})`}} />
      <AbsoluteFill style={{background: `rgba(0,0,0,${toBlack})`}} />
    </AbsoluteFill>
  );
};
