import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {CinematicText} from '../components/CinematicText';
import {Fog, Particles} from '../components/Particles';
import {Flash, LightSweep, StaticBurst} from '../components/Overlays';
import {colors, easeInOut, easeOut, fonts, hash, ramp} from '../styles/theme';

const ROWS = [
  {k: '', v: 'INCOMING CALL', at: 6},
  {k: 'TIME', v: '03:17 AM', at: 14},
  {k: 'FROM', v: 'EXT. 317', at: 22},
  {k: 'LOC', v: 'ROOM 317', at: 30},
  {k: 'DUR', v: '00:42', at: 38},
  {k: 'STATUS', v: 'ANSWERED', at: 118},
];

/** SCENE 05 - THE REVEAL (21-26 s). Call-log LCD, dramatic zoom onto FROM: EXT. 317. */
export const Scene05: React.FC = () => {
  const frame = useCurrentFrame();
  const punch = ramp(frame, 0, 10, 1.45, 1, easeOut);
  const main = frame < 108 ? ramp(frame, 38, 100, 1, 2.1, easeInOut) : ramp(frame, 108, 128, 2.1, 1.25, easeInOut);
  const lcdFlicker = 0.92 + 0.08 * hash(frame * 1.9);
  const hi = frame >= 52 ? 0.6 + 0.4 * Math.sin(frame * 0.5) : 0;

  return (
    <AbsoluteFill style={{backgroundColor: colors.black}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 30%, #0f1822 0%, #030405 70%)'}} />

      <div
        style={{
          position: 'absolute',
          left: 90,
          top: 150,
          width: 900,
          height: 1000,
          transform: `scale(${punch * main})`,
          transformOrigin: '50% 45%',
          borderRadius: 40,
          border: '14px solid #1d1f26',
          boxShadow: '0 40px 90px rgba(0,0,0,0.9), 0 0 80px rgba(60,160,220,0.25)',
          background: 'radial-gradient(ellipse at 50% 30%, #0e3040 0%, #041016 80%)',
          overflow: 'hidden',
          opacity: lcdFlicker,
          fontFamily: fonts.digital,
          fontWeight: 700,
          direction: 'ltr',
        }}
      >
        <div style={{position: 'absolute', left: 50, top: 55, fontSize: 38, color: '#8fe3ff', textShadow: '0 0 16px #3ab8e8', opacity: ramp(frame, 0, 6, 0, 1)}}>
          HOTEL PBX // CALL LOG
        </div>
        {ROWS.map((r, i) => {
          const chars = Math.floor(ramp(frame, r.at, r.at + 10, 0, r.v.length));
          const isStatus = r.k === 'STATUS';
          const color = isStatus ? '#ff4150' : '#8fe3ff';
          const shadow = isStatus ? '0 0 22px #e11d2e' : '0 0 18px #3ab8e8';
          const g = isStatus && frame >= 118 && frame < 130 && hash(frame * 2.7) > 0.6;
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: 50,
                right: 50,
                top: 170 + i * 110,
                height: 90,
                display: 'flex',
                alignItems: 'center',
                fontSize: 54,
                color,
                textShadow: g ? '8px 0 #ff2a55, -8px 0 #00c8ff' : shadow,
              }}
            >
              <span style={{width: 250, opacity: 0.55, fontSize: 40}}>{r.k}</span>
              <span>{r.v.slice(0, chars)}</span>
            </div>
          );
        })}
        {/* highlight box around FROM row */}
        <div
          style={{
            position: 'absolute',
            left: 30,
            right: 30,
            top: 170 + 2 * 110 - 6,
            height: 102,
            border: `5px solid ${colors.red}`,
            boxShadow: '0 0 30px rgba(225,29,46,0.8)',
            opacity: hi,
          }}
        />
        {/* scanlines */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.25) 0px, rgba(0,0,0,0.25) 2px, transparent 2px, transparent 4px)',
          }}
        />
      </div>

      <Fog color="rgba(70,110,170,0.25)" opacity={0.45} />
      <Particles count={40} opacity={0.45} seed={33} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(5,5,7,0) 56%, rgba(5,5,7,0.92) 76%)'}} />

      <CinematicText
        mode="replace"
        height={300}
        top={1130}
        lines={[
          {text: 'المفاجأة؟', start: 30, end: 66, size: 150, glitch: true},
          {text: 'المكالمة جاءت من داخل الغرفة!', start: 70, size: 100, color: '#ff4150', glow: 'rgba(225,29,46,0.85)', glitch: true},
        ]}
      />

      <Flash at={0} len={6} color="#ffffff" peak={0.85} />
      <LightSweep start={40} dur={35} />
      <Flash at={118} len={10} color="#e11d2e" peak={0.55} />
      <StaticBurst at={118} len={4} />
    </AbsoluteFill>
  );
};
