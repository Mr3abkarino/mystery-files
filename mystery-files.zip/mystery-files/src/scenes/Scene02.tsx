import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {HotelDoor} from '../components/HotelDoor';
import {CinematicText} from '../components/CinematicText';
import {Fog, Particles} from '../components/Particles';
import {LightSweep, StaticBurst} from '../components/Overlays';
import {colors, easeInOut, hash, ramp, TEXT_Y, W} from '../styles/theme';

/* ---------- one-point-perspective corridor ---------- */
const VPX = 540;
const VPY = 900;
const WX = 620;
const UP = 880;
const DN = 1020;
const ZEND = 7;
const sc = (z: number) => 1 / (1 + 0.6 * z);
const xl = (z: number) => VPX - WX * sc(z);
const xr = (z: number) => VPX + WX * sc(z);
const yc = (z: number) => VPY - UP * sc(z);
const yf = (z: number) => VPY + DN * sc(z);

const Corridor: React.FC<{f: number}> = ({f}) => {
  const doors: Array<[number, number]> = [
    [1.2, 2.1],
    [3.2, 4.1],
    [5.0, 5.7],
  ];
  const lights = [0.8, 2.6, 4.4, 6.0];
  const doorH = 1250;
  const endS = sc(ZEND);
  const endDoorW = 131;
  const endDoorH = (endDoorW * 1100) / 600;
  const redPulse = 0.45 + 0.35 * Math.sin(f * 0.45);

  return (
    <div style={{position: 'absolute', inset: 0}}>
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="mf-wl" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#04060a" />
            <stop offset="1" stopColor="#18222f" />
          </linearGradient>
          <linearGradient id="mf-wr" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#18222f" />
            <stop offset="1" stopColor="#04060a" />
          </linearGradient>
          <linearGradient id="mf-fl" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#141b24" />
            <stop offset="1" stopColor="#020304" />
          </linearGradient>
          <linearGradient id="mf-cl" x1="0" y1="1" x2="0" y2="0">
            <stop offset="0" stopColor="#0c1118" />
            <stop offset="1" stopColor="#020304" />
          </linearGradient>
          <radialGradient id="mf-lg" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#8fbfff" stopOpacity="0.7" />
            <stop offset="1" stopColor="#8fbfff" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="mf-endred" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#e11d2e" stopOpacity="0.9" />
            <stop offset="1" stopColor="#e11d2e" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width={1080} height={1920} fill="#020304" />
        <polygon points={`${xl(0)},${yc(0)} ${xl(ZEND)},${yc(ZEND)} ${xl(ZEND)},${yf(ZEND)} ${xl(0)},${yf(0)}`} fill="url(#mf-wl)" />
        <polygon points={`${xr(0)},${yc(0)} ${xr(ZEND)},${yc(ZEND)} ${xr(ZEND)},${yf(ZEND)} ${xr(0)},${yf(0)}`} fill="url(#mf-wr)" />
        <polygon points={`${xl(0)},${yf(0)} ${xr(0)},${yf(0)} ${xr(ZEND)},${yf(ZEND)} ${xl(ZEND)},${yf(ZEND)}`} fill="url(#mf-fl)" />
        <polygon points={`${xl(0)},${yc(0)} ${xr(0)},${yc(0)} ${xr(ZEND)},${yc(ZEND)} ${xl(ZEND)},${yc(ZEND)}`} fill="url(#mf-cl)" />
        <rect x={xl(ZEND)} y={yc(ZEND)} width={xr(ZEND) - xl(ZEND)} height={yf(ZEND) - yc(ZEND)} fill="#0a0d12" />

        {/* side doors */}
        {doors.map(([z1, z2], i) => {
          const top1 = VPY + (DN - doorH) * sc(z1);
          const top2 = VPY + (DN - doorH) * sc(z2);
          const L = `${xl(z1)},${yf(z1)} ${xl(z2)},${yf(z2)} ${xl(z2)},${top2} ${xl(z1)},${top1}`;
          const R = `${xr(z1)},${yf(z1)} ${xr(z2)},${yf(z2)} ${xr(z2)},${top2} ${xr(z1)},${top1}`;
          return (
            <g key={i}>
              <polygon points={L} fill="#1a110c" stroke="#05080b" strokeWidth={3} />
              <polygon points={R} fill="#1a110c" stroke="#05080b" strokeWidth={3} />
            </g>
          );
        })}

        {/* flickering ceiling lights + pooled light on the floor */}
        {lights.map((z, i) => {
          const I = hash(Math.floor(f / 2) + i * 7) > 0.14 ? 1 : 0.1;
          const s0 = sc(z);
          const s1 = sc(z + 0.5);
          return (
            <g key={i}>
              <ellipse cx={VPX} cy={yc(z) + 60 * s0} rx={300 * s0} ry={190 * s0} fill="url(#mf-lg)" opacity={0.6 * I} />
              <polygon
                points={`${VPX - 120 * s0},${yc(z)} ${VPX + 120 * s0},${yc(z)} ${VPX + 120 * s1},${yc(z + 0.5)} ${VPX - 120 * s1},${yc(z + 0.5)}`}
                fill={`rgba(200,225,255,${0.9 * I})`}
              />
              <ellipse cx={VPX} cy={yf(z + 0.3)} rx={320 * s0} ry={50 * s0} fill={`rgba(120,170,230,${0.12 * I})`} />
            </g>
          );
        })}

        {/* red emergency glow behind room 317 */}
        <ellipse cx={VPX} cy={yf(ZEND) - 120 * endS} rx={420 * endS * 2} ry={600 * endS * 2} fill="url(#mf-endred)" opacity={redPulse} />
      </svg>

      <div style={{position: 'absolute', left: VPX - endDoorW / 2, top: yf(ZEND) - endDoorH}}>
        <HotelDoor width={endDoorW} redLight={redPulse} glow={0.4 + 0.5 * redPulse} lockProgress={1} />
      </div>
    </div>
  );
};

/* ---------- close-up shots (door element is 900 wide at left 90 / top 135; plate at (450,495), locks at (727,1050) in its own box) ---------- */
const DoorShot: React.FC<{
  f: number;
  origin: [number, number];
  target: [number, number];
  scaleFrom: number;
  scaleTo: number;
  lock: number;
  plate: number;
}> = ({f, origin, target, scaleFrom, scaleTo, lock, plate}) => {
  const s = ramp(f, 0, 30, scaleFrom, scaleTo);
  const tx = target[0] - (90 + origin[0]);
  const ty = target[1] - (135 + origin[1]);
  const flick = 0.45 + 0.4 * Math.abs(Math.sin(f * 0.5));
  return (
    <AbsoluteFill>
      <div
        style={{
          position: 'absolute',
          left: 90,
          top: 135,
          transformOrigin: `${origin[0]}px ${origin[1]}px`,
          transform: `translate(${tx}px, ${ty}px) scale(${s})`,
        }}
      >
        <HotelDoor width={900} redLight={flick} glow={flick} lockProgress={lock} highlightPlate={plate} />
      </div>
    </AbsoluteFill>
  );
};

const SealedWindow: React.FC<{f: number}> = ({f}) => {
  const s = ramp(f, 0, 50, 1, 1.18);
  return (
    <AbsoluteFill>
      <svg width={980} height={1306} viewBox="0 0 600 800" style={{position: 'absolute', left: 50, top: 140, transform: `scale(${s})`}}>
        <defs>
          <linearGradient id="mf-night" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#2f5078" />
            <stop offset="1" stopColor="#0f1d30" />
          </linearGradient>
        </defs>
        <rect width={600} height={800} fill="#0a0d12" />
        <rect x={110} y={80} width={380} height={560} fill="url(#mf-night)" stroke="#05080b" strokeWidth={14} />
        <path d="M300 80V640M110 360H490" stroke="#05080b" strokeWidth={12} />
        <polygon points="110,640 490,640 560,800 40,800" fill="#7fb2e5" opacity={0.08} />
        <g transform="rotate(-9 300 300)">
          <rect x={40} y={250} width={520} height={60} fill="#3b2a1d" stroke="#120b07" strokeWidth={3} />
          <circle cx={70} cy={280} r={6} fill="#111" />
          <circle cx={530} cy={280} r={6} fill="#111" />
        </g>
        <g transform="rotate(8 300 450)">
          <rect x={40} y={420} width={520} height={60} fill="#33241a" stroke="#120b07" strokeWidth={3} />
          <circle cx={70} cy={450} r={6} fill="#111" />
          <circle cx={530} cy={450} r={6} fill="#111" />
        </g>
        <g transform="rotate(-14 300 560)">
          <rect x={20} y={535} width={560} height={50} fill="#b3121e" opacity={0.92} />
          <text x={300} y={571} textAnchor="middle" fontSize={34} fontWeight="bold" fontFamily="'Courier New', monospace" fill="#f2dcd8">
            SEALED
          </text>
        </g>
      </svg>
    </AbsoluteFill>
  );
};

/** SCENE 02 - THE MYSTERY (3-8 s). Four hard-cut shots: corridor, plate 317, locks, sealed window. */
export const Scene02: React.FC = () => {
  const frame = useCurrentFrame();
  const cuts = [0, 40, 68, 100];
  const shot = frame < 40 ? 0 : frame < 68 ? 1 : frame < 100 ? 2 : 3;
  const since = frame - cuts[shot];
  const shake = since < 5 ? ramp(since, 0, 5, 22, 0) : 0;
  const cx = (hash(frame * 1.7) - 0.5) * shake;
  const cy = (hash(frame * 2.9) - 0.5) * shake;
  const push = ramp(frame, 0, 40, 1, 2.3, easeInOut);

  return (
    <AbsoluteFill style={{backgroundColor: colors.black}}>
      <AbsoluteFill style={{transform: `translate(${cx}px, ${cy}px)`}}>
        {shot === 0 && (
          <AbsoluteFill style={{transform: `scale(${push})`, transformOrigin: `${W / 2}px 976px`}}>
            <Corridor f={frame} />
          </AbsoluteFill>
        )}
        {shot === 1 && (
          <DoorShot f={since} origin={[450, 495]} target={[540, 760]} scaleFrom={2.7} scaleTo={3.1} lock={1} plate={ramp(since, 4, 20, 0, 1)} />
        )}
        {shot === 2 && (
          <DoorShot f={since} origin={[727, 1050]} target={[540, 800]} scaleFrom={2.2} scaleTo={2.5} lock={ramp(since, 4, 26, 0, 1)} plate={0} />
        )}
        {shot === 3 && <SealedWindow f={since} />}
      </AbsoluteFill>

      <Fog color="rgba(70,110,170,0.3)" opacity={0.5} />
      <Particles count={45} opacity={0.5} seed={4} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(5,5,7,0) 58%, rgba(5,5,7,0.92) 78%)'}} />

      <CinematicText
        mode="replace"
        height={300}
        top={TEXT_Y}
        lines={[
          {text: 'الباب كان مغلقًا من الداخل', start: 8, end: 96, size: 100},
          {text: 'والنوافذ لم تُفتح!', start: 104, size: 120, color: '#ff4150', glow: 'rgba(225,29,46,0.8)', glitch: true},
        ]}
      />

      <LightSweep start={50} dur={30} />
      <StaticBurst at={40} len={3} />
      <StaticBurst at={68} len={3} />
      <StaticBurst at={100} len={3} />
    </AbsoluteFill>
  );
};
