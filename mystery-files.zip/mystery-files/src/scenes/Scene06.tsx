import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {CinematicText} from '../components/CinematicText';
import {Fog, Particles} from '../components/Particles';
import {FilmBurn, LightSlit, StaticBurst} from '../components/Overlays';
import {colors, fonts, hash, ramp, W} from '../styles/theme';

const FrostedDoor: React.FC<{f: number; dim: number}> = ({f, dim}) => {
  const light = 0.5 + 0.5 * (hash(Math.floor(f / 3)) > 0.25 ? 1 : 0.2);
  const sil = ramp(f, 15, 40, 0, 0.85);
  const drift = ramp(f, 15, 80, 0, 18);
  const step = ramp(f, 15, 80, 0.92, 1.08);
  return (
    <svg width={560} height={1000} viewBox="0 0 560 1000" style={{position: 'absolute', left: 260, top: 180, opacity: dim}}>
      <defs>
        <linearGradient id="mf-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#a5c8f0" stopOpacity="0.5" />
          <stop offset="1" stopColor="#3c5a82" stopOpacity="0.2" />
        </linearGradient>
        <filter id="mf-blur14">
          <feGaussianBlur stdDeviation="14" />
        </filter>
        <filter id="mf-frost">
          <feTurbulence type="fractalNoise" baseFrequency="0.015 0.6" numOctaves={3} seed={3} result="n" />
          <feColorMatrix in="n" type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.9 -0.25" />
        </filter>
      </defs>
      <rect width={560} height={1000} fill="#0a0b0e" stroke="#23262d" strokeWidth={10} />
      <rect x={30} y={30} width={500} height={940} fill="url(#mf-glass)" opacity={light} />
      <g filter="url(#mf-blur14)" opacity={sil} transform={`translate(${drift} 0) translate(280 900) scale(${step}) translate(-280 -900)`}>
        <circle cx={280} cy={430} r={62} fill="#020203" />
        <path d="M130 900 Q130 560 280 520 Q430 560 430 900 Z" fill="#020203" />
      </g>
      <rect x={30} y={30} width={500} height={940} filter="url(#mf-frost)" opacity={0.55} />
      <rect x={30} y={480} width={500} height={10} fill="#0a0b0e" />
      <rect x={485} y={500} width={12} height={90} rx={6} fill="#8a8f98" />
    </svg>
  );
};

/** SCENE 06 - THE FINAL HOOK (26-30 s). Silhouette behind frosted glass, closing question, end card, loop to frame 0. */
export const Scene06: React.FC = () => {
  const frame = useCurrentFrame();
  const doorDim = ramp(frame, 78, 96, 1, 0.12);
  const titleOp = ramp(frame, 82, 90, 0, 1);
  const titleScale = ramp(frame, 82, 118, 1.12, 1);
  const g = frame >= 82 && frame < 94 && hash(frame * 2.3) > 0.45;
  const dx = g ? 8 + hash(frame) * 12 : 0;
  const ctaPulse = 1 + 0.03 * Math.sin(frame * 0.3);
  const toBlack = ramp(frame, 104, 116, 0, 1);

  return (
    <AbsoluteFill style={{backgroundColor: colors.black}}>
      <FrostedDoor f={frame} dim={doorDim} />
      <Fog color="rgba(70,110,170,0.3)" opacity={0.5} />
      <Particles count={45} opacity={0.5} seed={50} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(5,5,7,0) 52%, rgba(5,5,7,0.92) 74%)'}} />

      <CinematicText
        top={1100}
        lines={[
          {text: 'إذا لم يكن هناك أحد...', start: 30, end: 78, size: 84},
          {text: 'فمن الذي ردّ على الهاتف؟', start: 55, end: 78, size: 110, color: '#ff4150', glow: 'rgba(225,29,46,0.85)', glitch: true},
        ]}
      />

      {/* end card */}
      <div style={{position: 'absolute', left: 0, width: W, top: 560, textAlign: 'center', opacity: titleOp, transform: `scale(${titleScale})`}}>
        <div
          style={{
            fontFamily: fonts.digital,
            fontWeight: 900,
            fontSize: 76,
            letterSpacing: 3,
            color: colors.bone,
            textShadow: g ? `${dx}px 0 #ff2a55, ${-dx}px 0 #00c8ff` : '0 0 30px rgba(111,168,220,0.6)',
          }}
        >
          MYSTERY FILES
        </div>
        <div style={{margin: '26px auto', height: 4, width: ramp(frame, 86, 104, 0, 520), background: colors.red, boxShadow: '0 0 20px rgba(225,29,46,0.9)'}} />
        <div style={{fontFamily: fonts.digital, fontWeight: 900, fontSize: 64, letterSpacing: 14, color: '#ff4150', textShadow: '0 0 28px rgba(225,29,46,0.9)'}}>
          CASE 001
        </div>
      </div>
      <div
        dir="rtl"
        lang="ar"
        style={{
          position: 'absolute',
          left: 60,
          width: W - 120,
          top: 1150,
          textAlign: 'center',
          fontFamily: fonts.arabic,
          fontWeight: 900,
          fontSize: 78,
          color: colors.bone,
          opacity: ramp(frame, 92, 100, 0, 1),
          transform: `scale(${ctaPulse})`,
          textShadow: '0 0 30px rgba(111,168,220,0.6), 0 6px 24px rgba(0,0,0,0.95)',
        }}
      >
        اكتب توقعك في التعليقات!
      </div>

      <FilmBurn at={0} len={20} peak={0.45} />
      <StaticBurst at={82} len={3} />
      <AbsoluteFill style={{background: `rgba(0,0,0,${toBlack})`}} />
      {/* last frame == first frame: black with the thin red slit -> seamless loop */}
      <LightSlit opacity={ramp(frame, 106, 119, 0, 0.85)} />
    </AbsoluteFill>
  );
};
