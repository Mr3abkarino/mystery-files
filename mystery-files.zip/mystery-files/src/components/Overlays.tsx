import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, W, hash, ramp} from '../styles/theme';

export const Vignette: React.FC<{strength?: number}> = ({strength = 0.88}) => (
  <AbsoluteFill
    style={{
      pointerEvents: 'none',
      background: `radial-gradient(ellipse at 50% 48%, rgba(0,0,0,0) 38%, rgba(0,0,0,${strength}) 100%)`,
    }}
  />
);

/** Cold-shadow / crimson-highlight colour grade. */
export const ColorGrade: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: 'none',
      mixBlendMode: 'soft-light',
      background: 'linear-gradient(180deg, rgba(40,90,160,0.20) 0%, rgba(120,10,25,0.14) 100%)',
    }}
  />
);

/** Fake depth of field: blurred edges, sharp centre. */
export const EdgeBlur: React.FC = () => {
  const mask = 'radial-gradient(ellipse at 50% 50%, transparent 42%, black 100%)';
  return (
    <AbsoluteFill
      style={{pointerEvents: 'none', backdropFilter: 'blur(5px)', WebkitMaskImage: mask, maskImage: mask}}
    />
  );
};

/** Diagonal cinematic light sweep. */
export const LightSweep: React.FC<{start: number; dur?: number; color?: string; peak?: number}> = ({
  start,
  dur = 40,
  color = 'rgba(160,200,255,0.55)',
  peak = 1,
}) => {
  const frame = useCurrentFrame();
  if (frame < start - 1 || frame > start + dur + 1) return null;
  const p = ramp(frame, start, start + dur, -0.45, 1.3);
  return (
    <AbsoluteFill style={{pointerEvents: 'none', mixBlendMode: 'screen', opacity: 0.55 * peak, overflow: 'hidden'}}>
      <div
        style={{
          position: 'absolute',
          top: -200,
          bottom: -200,
          width: 340,
          left: p * W,
          transform: 'skewX(-20deg)',
          background: `linear-gradient(90deg, transparent, ${color}, transparent)`,
          filter: 'blur(26px)',
        }}
      />
    </AbsoluteFill>
  );
};

/** Hard-cut glitch: horizontal static bars. Visible for `len` frames starting at `at`. */
export const StaticBurst: React.FC<{at: number; len?: number}> = ({at, len = 3}) => {
  const frame = useCurrentFrame();
  if (frame < at || frame >= at + len) return null;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', mixBlendMode: 'screen', background: 'rgba(255,255,255,0.10)'}}>
      {Array.from({length: 16}).map((_, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: 0,
            width: W,
            top: hash(frame * 3.1 + i * 11) * H,
            height: 4 + hash(frame + i * 5) * 50,
            background: `rgba(210,230,255,${0.25 + hash(i + frame) * 0.55})`,
            transform: `translateX(${(hash(i * 7 + frame) - 0.5) * 80}px)`,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

export const Flash: React.FC<{at: number; len?: number; color?: string; peak?: number}> = ({
  at,
  len = 8,
  color = '#ffffff',
  peak = 0.8,
}) => {
  const frame = useCurrentFrame();
  if (frame < at || frame >= at + len) return null;
  return <AbsoluteFill style={{pointerEvents: 'none', background: color, opacity: ramp(frame, at, at + len, peak, 0)}} />;
};

/** Film-burn transition: warm light leak that swells and dies. */
export const FilmBurn: React.FC<{at: number; len?: number; peak?: number}> = ({at, len = 16, peak = 0.8}) => {
  const frame = useCurrentFrame();
  const f = frame - at;
  if (f < 0 || f >= len) return null;
  const o = peak * Math.sin(Math.PI * (f / len));
  return (
    <AbsoluteFill
      style={{
        pointerEvents: 'none',
        mixBlendMode: 'screen',
        opacity: o,
        background: `radial-gradient(ellipse at ${30 + hash(frame) * 40}% ${40 + hash(frame + 9) * 20}%, #ffb060 0%, #ff4a1a 35%, #5a0a0a 70%, rgba(0,0,0,0) 100%)`,
      }}
    />
  );
};

/** Thin red vertical light slit - the shared frame between the last and first frames (seamless loop). */
export const LightSlit: React.FC<{opacity: number}> = ({opacity}) => {
  if (opacity <= 0.01) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: W / 2 - 3,
        top: H / 2 - 550,
        width: 6,
        height: 1100,
        background: '#e11d2e',
        opacity,
        boxShadow: '0 0 40px 14px rgba(225,29,46,0.7)',
      }}
    />
  );
};
