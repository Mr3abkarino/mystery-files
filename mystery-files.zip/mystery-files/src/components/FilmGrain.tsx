import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, W, hash} from '../styles/theme';

/** Animated film grain (SVG turbulence, new seed every frame) + occasional film scratches. */
export const FilmGrain: React.FC<{opacity?: number}> = ({opacity = 0.2}) => {
  const frame = useCurrentFrame();
  const seed = frame % 7;
  const jx = (hash(frame * 1.3) - 0.5) * 60;
  const jy = (hash(frame * 2.1) - 0.5) * 60;
  const scratch = hash(frame * 0.37) > 0.93;
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{mixBlendMode: 'overlay', opacity}}>
        <svg
          width={W}
          height={H}
          style={{position: 'absolute', left: 0, top: 0, transform: `translate(${jx}px, ${jy}px) scale(1.15)`}}
        >
          <filter id="mf-grain" x="0" y="0" width="100%" height="100%">
            <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={seed} stitchTiles="stitch" />
            <feColorMatrix type="saturate" values="0" />
          </filter>
          <rect width={W} height={H} filter="url(#mf-grain)" />
        </svg>
      </AbsoluteFill>
      {scratch ? (
        <div
          style={{
            position: 'absolute',
            left: hash(frame * 5.1) * W,
            top: 0,
            width: 2,
            height: H,
            background: 'rgba(255,255,255,0.22)',
          }}
        />
      ) : null}
    </AbsoluteFill>
  );
};
