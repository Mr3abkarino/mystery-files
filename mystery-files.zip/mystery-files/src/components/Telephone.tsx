import React from 'react';
import {useCurrentFrame} from 'remotion';
import {colors, hash} from '../styles/theme';

/** Vintage rotary telephone. `ring` 0..1 shakes the body and bounces the handset. viewBox 800x700. */
export const Telephone: React.FC<{width?: number; ring?: number; redGlow?: number}> = ({width = 800, ring = 0, redGlow = 0}) => {
  const frame = useCurrentFrame();
  const rot = ring * Math.sin(frame * 2.4) * 1.4;
  const jy = ring * (hash(frame * 3.3) - 0.5) * 10;
  const handsetY = ring * Math.abs(Math.sin(frame * 1.9)) * -16;
  const holes = Array.from({length: 10}).map((_, i) => {
    const a = ((35 + i * 27) * Math.PI) / 180;
    return {x: 400 + Math.cos(a) * 100, y: 430 + Math.sin(a) * 100};
  });
  return (
    <svg width={width} height={(width * 700) / 800} viewBox="0 0 800 700" style={{overflow: 'visible'}}>
      <defs>
        <linearGradient id="mf-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#262830" />
          <stop offset="1" stopColor="#07080a" />
        </linearGradient>
        <radialGradient id="mf-dial" cx="0.4" cy="0.35" r="0.8">
          <stop offset="0" stopColor="#2b3038" />
          <stop offset="1" stopColor="#0a0b0e" />
        </radialGradient>
        <radialGradient id="mf-pglow" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor={colors.red} stopOpacity="0.9" />
          <stop offset="1" stopColor={colors.red} stopOpacity="0" />
        </radialGradient>
      </defs>
      <ellipse cx={400} cy={610} rx={330} ry={40} fill="#000" opacity={0.6} />
      <g transform={`translate(0 ${jy}) rotate(${rot} 400 450)`}>
        {/* cord */}
        <path d="M690 560 C760 600 780 650 700 670 S 500 690 400 660" stroke="#0b0c0f" strokeWidth={14} fill="none" strokeLinecap="round" />
        {/* body */}
        <path
          d="M110 580 Q95 580 105 540 L205 335 Q222 300 262 300 L538 300 Q578 300 595 335 L695 540 Q705 580 690 580 Z"
          fill="url(#mf-body)"
          stroke="#000"
          strokeWidth={3}
        />
        <path d="M215 340 Q400 310 585 340" stroke="rgba(150,190,255,0.35)" strokeWidth={4} fill="none" strokeLinecap="round" />
        {/* dial */}
        <circle cx={400} cy={430} r={150} fill="#0a0b0e" stroke="#3a3d46" strokeWidth={4} />
        <circle cx={400} cy={430} r={138} fill="url(#mf-dial)" />
        {holes.map((h, i) => (
          <circle key={i} cx={h.x} cy={h.y} r={22} fill="#020203" stroke="#50545f" strokeWidth={3} />
        ))}
        <circle cx={400} cy={430} r={46} fill="#14151a" stroke="#4a4e58" strokeWidth={3} />
        <circle cx={400} cy={430} r={18} fill="#08090b" />
        {/* handset */}
        <g transform={`translate(0 ${handsetY})`}>
          <path d="M135 245 Q400 105 665 245" stroke="#0d0e12" strokeWidth={64} fill="none" strokeLinecap="round" />
          <path d="M150 215 Q400 80 650 215" stroke="rgba(180,210,255,0.28)" strokeWidth={6} fill="none" strokeLinecap="round" />
          <ellipse cx={135} cy={245} rx={58} ry={46} fill="#0d0e12" stroke="#2a2d35" strokeWidth={3} />
          <ellipse cx={665} cy={245} rx={58} ry={46} fill="#0d0e12" stroke="#2a2d35" strokeWidth={3} />
        </g>
        <ellipse cx={400} cy={430} rx={420} ry={300} fill="url(#mf-pglow)" opacity={redGlow} style={{mixBlendMode: 'screen'}} />
      </g>
    </svg>
  );
};
