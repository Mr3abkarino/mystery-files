import React from 'react';
import {colors} from '../styles/theme';

type Props = {
  width?: number;
  /** 0..1 red emergency wash over the door */
  redLight?: number;
  /** 0 = unlocked, 1 = all locks engaged (bolts turned, chain across) */
  lockProgress?: number;
  /** 0..1 red light leaking under the door */
  glow?: number;
  /** 0..1 shine on the number plate */
  highlightPlate?: number;
};

const Panel: React.FC<{x: number; y: number; w: number; h: number}> = ({x, y, w, h}) => (
  <g>
    <rect x={x} y={y} width={w} height={h} fill="#1b100b" stroke="#050302" strokeWidth={4} />
    <path d={`M${x} ${y + h} L${x} ${y} L${x + w} ${y}`} stroke="rgba(160,190,230,0.2)" strokeWidth={3} fill="none" />
  </g>
);

/** Procedural SVG hotel door, room 317, with deadbolts, chain and latch. viewBox 600x1100. */
export const HotelDoor: React.FC<Props> = ({width = 600, redLight = 0, lockProgress = 1, glow = 0.3, highlightPlate = 0}) => {
  const height = (width * 1100) / 600;
  const boltAngle = lockProgress * 90;
  // chain: anchored right at (530,470); free end slides to the slot at (450,470) when locked, hangs when open
  const endX = 450 + 80 * (1 - lockProgress);
  const endY = 470 + 90 * (1 - lockProgress);
  const links = Array.from({length: 9}).map((_, i) => {
    const t = i / 8;
    const x = 530 + (endX - 530) * t;
    const y = 470 + (endY - 470) * t + Math.sin(Math.PI * t) * 16;
    return {x, y, rot: i % 2 === 0 ? 0 : 90};
  });

  return (
    <svg width={width} height={height} viewBox="0 0 600 1100">
      <defs>
        <linearGradient id="mf-wood" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2c1b13" />
          <stop offset="1" stopColor="#140b08" />
        </linearGradient>
        <linearGradient id="mf-brass" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#c9ab5f" />
          <stop offset="1" stopColor="#6e5a2a" />
        </linearGradient>
        <radialGradient id="mf-redwash" cx="0.5" cy="0" r="1">
          <stop offset="0" stopColor={colors.red} stopOpacity="0.85" />
          <stop offset="1" stopColor={colors.red} stopOpacity="0" />
        </radialGradient>
        <linearGradient id="mf-under" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={colors.red} stopOpacity="0.9" />
          <stop offset="1" stopColor={colors.red} stopOpacity="0" />
        </linearGradient>
        <linearGradient id="mf-rim" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#6fa8dc" stopOpacity="0.28" />
          <stop offset="0.25" stopColor="#6fa8dc" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* frame + leaf */}
      <rect x={6} y={6} width={588} height={1088} rx={6} fill="#0d0b0a" stroke="#2a2622" strokeWidth={6} />
      <rect x={50} y={50} width={500} height={1030} fill="url(#mf-wood)" />

      {/* panels */}
      {[90, 410, 760].map((y, r) =>
        [90, 275].map((x, c) => (
          <Panel key={`${r}-${c}`} x={x} y={y} w={c === 0 ? 170 : 150} h={[150, 300, 270][r]} />
        ))
      )}

      {/* peephole */}
      <circle cx={300} cy={262} r={9} fill="#05070a" stroke="#8a8f98" strokeWidth={3} />

      {/* number plate */}
      <rect x={190} y={285} width={220} height={90} rx={6} fill="url(#mf-brass)" stroke="#2a2010" strokeWidth={3} />
      <text x={300} y={352} textAnchor="middle" fontSize={62} fontWeight={700} fontFamily="Georgia, serif" fill="#1a1409">
        317
      </text>
      <rect x={190} y={285} width={220} height={90} rx={6} fill="#ffffff" opacity={0.35 * highlightPlate} />

      {/* chain lock */}
      <rect x={430} y={458} width={110} height={24} rx={6} fill="#4b4f57" />
      {links.map((l, i) => (
        <ellipse key={i} cx={l.x} cy={l.y} rx={9} ry={5} fill="none" stroke="#b9bec7" strokeWidth={3} transform={`rotate(${l.rot} ${l.x} ${l.y})`} />
      ))}

      {/* deadbolt #1 */}
      <circle cx={485} cy={540} r={30} fill="#8a8f98" stroke="#2a2d33" strokeWidth={4} />
      <g transform={`translate(485 540) rotate(${boltAngle})`}>
        <rect x={-4} y={-22} width={8} height={44} fill="#15171a" />
      </g>

      {/* handle */}
      <rect x={455} y={600} width={60} height={130} rx={12} fill="#7d8188" stroke="#2a2d33" strokeWidth={3} />
      <rect x={380} y={640} width={130} height={24} rx={12} fill="#a3a8b0" />
      <circle cx={485} cy={652} r={14} fill="#c1c6ce" />

      {/* latch + deadbolt #2 */}
      <rect x={455} y={760} width={70} height={40} rx={4} fill="#6b6f77" stroke="#2a2d33" strokeWidth={3} />
      <rect x={455 - 36 * lockProgress} y={772} width={44} height={16} fill="#b9bec7" />
      <circle cx={485} cy={860} r={24} fill="#8a8f98" stroke="#2a2d33" strokeWidth={4} />
      <g transform={`translate(485 860) rotate(${boltAngle})`}>
        <rect x={-3} y={-18} width={6} height={36} fill="#15171a" />
      </g>

      {/* light under the door */}
      <rect x={50} y={1078} width={500} height={6} fill={colors.red} opacity={glow} />
      <rect x={30} y={1082} width={540} height={18} fill="url(#mf-under)" opacity={glow} />

      {/* grading: cold rim light + red emergency wash */}
      <rect x={50} y={50} width={500} height={1030} fill="url(#mf-rim)" />
      <rect x={50} y={50} width={500} height={1030} fill="url(#mf-redwash)" opacity={redLight} />
    </svg>
  );
};
