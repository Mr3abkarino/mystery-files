import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {colors, easeOut, fonts, H, ramp, W} from '../styles/theme';

type Kind = 'room' | 'camera' | 'door' | 'person' | 'unknown';
type Card = {id: string; kind: Kind; x: number; y: number; w: number; h: number; rot: number; label: string; delay: number};

const CARDS: Card[] = [
  {id: 'room', kind: 'room', x: 70, y: 210, w: 440, h: 330, rot: -4, label: 'غرفة 317', delay: 6},
  {id: 'cam', kind: 'camera', x: 575, y: 240, w: 440, h: 330, rot: 3.5, label: 'كاميرا المراقبة', delay: 18},
  {id: 'door', kind: 'door', x: 90, y: 640, w: 330, h: 410, rot: 2.5, label: 'باب مغلق', delay: 30},
  {id: 'person', kind: 'person', x: 640, y: 660, w: 340, h: 400, rot: -3, label: 'المفقود', delay: 42},
  {id: 'unknown', kind: 'unknown', x: 395, y: 850, w: 290, h: 210, rot: -1.5, label: 'من؟', delay: 54},
];

const STRINGS: Array<[string, string]> = [
  ['room', 'cam'],
  ['room', 'door'],
  ['cam', 'person'],
  ['door', 'unknown'],
  ['person', 'unknown'],
  ['room', 'person'],
  ['cam', 'door'],
];

const byId = (id: string): Card => CARDS.find((c) => c.id === id) as Card;
const pin = (c: Card) => ({x: c.x + c.w / 2, y: c.y + 10});

/* ---------- illustrations (pure SVG) ---------- */

const RoomArt: React.FC<{w: number; h: number}> = ({w, h}) => {
  const frame = useCurrentFrame();
  const flick = 0.85 + 0.15 * Math.sin(frame * 0.3);
  return (
    <svg width={w} height={h} viewBox="0 0 400 260" preserveAspectRatio="xMidYMid slice">
      <defs>
        <linearGradient id="mf-room" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#14202e" />
          <stop offset="1" stopColor="#080b10" />
        </linearGradient>
      </defs>
      <rect width={400} height={260} fill="url(#mf-room)" />
      <rect x={250} y={30} width={110} height={120} fill="#2b4a6e" opacity={flick} />
      <path d="M305 30V150M250 90H360" stroke="#0a0f16" strokeWidth={5} />
      <polygon points="250,150 360,150 330,260 150,260" fill="#7fb2e5" opacity={0.08} />
      <rect x={30} y={150} width={190} height={70} fill="#2a1a1f" />
      <rect x={30} y={132} width={60} height={30} fill="#3a2630" />
      <rect x={232} y={170} width={10} height={50} fill="#222" />
      <path d="M222 170 L252 170 L246 148 L228 148Z" fill="#7a5a2a" opacity={0.7} />
      <rect x={262} y={205} width={50} height={14} fill="#111" />
      <rect y={220} width={400} height={40} fill="#05070a" />
    </svg>
  );
};

const CameraArt: React.FC<{w: number; h: number}> = ({w, h}) => {
  const frame = useCurrentFrame();
  return (
    <svg width={w} height={h} viewBox="0 0 400 260" preserveAspectRatio="xMidYMid slice">
      <defs>
        <pattern id="mf-scan" width={4} height={4} patternUnits="userSpaceOnUse">
          <rect width={4} height={1.5} fill="rgba(0,0,0,0.35)" />
        </pattern>
      </defs>
      <rect width={400} height={260} fill="#0b1013" />
      <path d="M0 0L170 105M400 0L230 105M0 260L170 150M400 260L230 150" stroke="#3d5563" strokeWidth={2} />
      <rect x={170} y={105} width={60} height={45} stroke="#3d5563" fill="#0a0f12" />
      <rect width={400} height={260} fill="url(#mf-scan)" />
      <rect y={(frame * 7) % 300 - 20} width={400} height={14} fill="rgba(200,230,255,0.18)" />
      <circle cx={28} cy={24} r={7} fill="#e11d2e" opacity={frame % 30 < 18 ? 1 : 0.15} />
      <text x={44} y={30} fill="#cfe8ff" fontSize={18} fontFamily="monospace">
        REC  CAM 03
      </text>
      <text x={20} y={244} fill="#cfe8ff" fontSize={18} fontFamily="monospace">
        03:16:42  NO MOTION
      </text>
    </svg>
  );
};

const DoorArt: React.FC<{w: number; h: number}> = ({w, h}) => (
  <svg width={w} height={h} viewBox="0 0 300 330" preserveAspectRatio="xMidYMid slice">
    <rect width={300} height={330} fill="#0b0d11" />
    <rect x={60} y={20} width={180} height={300} fill="#2b1a12" stroke="#050302" strokeWidth={4} />
    <rect x={80} y={40} width={65} height={90} fill="#1b100b" />
    <rect x={155} y={40} width={65} height={90} fill="#1b100b" />
    <rect x={80} y={160} width={140} height={140} fill="#1b100b" />
    <circle cx={205} cy={150} r={13} fill="#8a8f98" />
    <rect x={190} y={190} width={30} height={10} rx={5} fill="#a3a8b0" />
    <g transform="rotate(-14 150 190)">
      <rect x={40} y={165} width={220} height={50} fill="rgba(5,5,7,0.55)" stroke="#e11d2e" strokeWidth={5} />
      <text x={150} y={202} textAnchor="middle" fontSize={34} fontWeight="bold" fontFamily="'Courier New', monospace" fill="#e11d2e">
        LOCKED
      </text>
    </g>
  </svg>
);

const PersonArt: React.FC<{w: number; h: number}> = ({w, h}) => {
  const frame = useCurrentFrame();
  return (
    <svg width={w} height={h} viewBox="0 0 300 330" preserveAspectRatio="xMidYMid slice">
      <defs>
        <linearGradient id="mf-pbg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1a1c22" />
          <stop offset="1" stopColor="#08090c" />
        </linearGradient>
      </defs>
      <rect width={300} height={330} fill="url(#mf-pbg)" />
      <circle cx={150} cy={110} r={48} fill="#030304" stroke="#cfd6e0" strokeWidth={3} strokeDasharray="8 6" />
      <path d="M60 330 Q60 200 150 180 Q240 200 240 330 Z" fill="#030304" stroke="#cfd6e0" strokeWidth={3} strokeDasharray="8 6" />
      <text
        x={150}
        y={290}
        textAnchor="middle"
        fontSize={110}
        fontFamily={fonts.arabic}
        fontWeight={900}
        fill="#e11d2e"
        opacity={0.55 + 0.25 * Math.sin(frame * 0.2)}
      >
        ؟
      </text>
    </svg>
  );
};

const UnknownArt: React.FC<{w: number; h: number}> = ({w, h}) => (
  <svg width={w} height={h} viewBox="0 0 260 130" preserveAspectRatio="xMidYMid slice">
    <rect width={260} height={130} fill="#0d0e12" />
    <path d="M0 20H260M0 110H260" stroke="#1d2027" strokeWidth={2} />
    <text x={130} y={108} textAnchor="middle" fontSize={120} fontFamily={fonts.arabic} fontWeight={900} fill="#8a1520">
      ؟
    </text>
  </svg>
);

const Art: React.FC<{kind: Kind; w: number; h: number}> = ({kind, w, h}) => {
  switch (kind) {
    case 'room':
      return <RoomArt w={w} h={h} />;
    case 'camera':
      return <CameraArt w={w} h={h} />;
    case 'door':
      return <DoorArt w={w} h={h} />;
    case 'person':
      return <PersonArt w={w} h={h} />;
    default:
      return <UnknownArt w={w} h={h} />;
  }
};

const CardView: React.FC<{card: Card}> = ({card}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: Math.max(0, frame - card.delay), fps, config: {damping: 12, stiffness: 110, mass: 0.8}});
  const op = ramp(frame, card.delay, card.delay + 4, 0, 1);
  const innerW = card.w - 28;
  const innerH = card.h - 28 - 64;
  return (
    <div
      style={{
        position: 'absolute',
        left: card.x,
        top: card.y,
        width: card.w,
        height: card.h,
        opacity: op,
        transform: `translateY(${(1 - p) * -120}px) scale(${1.5 - 0.5 * p}) rotate(${card.rot}deg)`,
        background: '#d8d1bf',
        padding: 14,
        boxSizing: 'border-box',
        boxShadow: '0 30px 60px rgba(0,0,0,0.8)',
      }}
    >
      <div style={{width: innerW, height: innerH, overflow: 'hidden', background: '#000'}}>
        <Art kind={card.kind} w={innerW} h={innerH} />
      </div>
      <div
        dir="rtl"
        lang="ar"
        style={{
          fontFamily: fonts.arabic,
          fontWeight: 800,
          fontSize: 38,
          color: '#17130f',
          textAlign: 'center',
          lineHeight: '56px',
          height: 56,
          marginTop: 8,
        }}
      >
        {card.label}
      </div>
    </div>
  );
};

/** Detective evidence board: cards drop in, pins land, red strings draw themselves. */
export const EvidenceBoard: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <div style={{position: 'absolute', inset: 0, overflow: 'hidden'}}>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'radial-gradient(ellipse at 50% 35%, #2a241e 0%, #120f0c 60%, #050403 100%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'repeating-linear-gradient(45deg, rgba(255,255,255,0.018) 0px, rgba(255,255,255,0.018) 2px, transparent 2px, transparent 7px)',
        }}
      />
      {CARDS.map((c) => (
        <CardView key={c.id} card={c} />
      ))}
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <radialGradient id="mf-pin" cx="0.35" cy="0.3" r="0.8">
            <stop offset="0" stopColor="#ff8a8f" />
            <stop offset="0.4" stopColor={colors.red} />
            <stop offset="1" stopColor={colors.crimson} />
          </radialGradient>
        </defs>
        {STRINGS.map(([a, b], i) => {
          const A = pin(byId(a));
          const B = pin(byId(b));
          const p = ramp(frame, 66 + i * 9, 82 + i * 9, 0, 1, easeOut);
          if (p <= 0) return null;
          const mx = (A.x + B.x) / 2;
          const my = (A.y + B.y) / 2 + 55;
          return (
            <path
              key={i}
              d={`M${A.x} ${A.y} Q${mx} ${my} ${B.x} ${B.y}`}
              pathLength={1}
              strokeDasharray={1}
              strokeDashoffset={1 - p}
              stroke={colors.red}
              strokeWidth={5}
              fill="none"
              strokeLinecap="round"
              style={{filter: 'drop-shadow(0 4px 6px rgba(0,0,0,0.8))'}}
            />
          );
        })}
        {CARDS.map((c) => {
          const P = pin(c);
          return (
            <circle
              key={c.id}
              cx={P.x}
              cy={P.y}
              r={13}
              fill="url(#mf-pin)"
              opacity={ramp(frame, c.delay + 6, c.delay + 9, 0, 1)}
              style={{filter: 'drop-shadow(0 5px 5px rgba(0,0,0,0.8))'}}
            />
          );
        })}
      </svg>
    </div>
  );
};
