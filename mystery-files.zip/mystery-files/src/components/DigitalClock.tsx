import React from 'react';
import {useCurrentFrame} from 'remotion';
import {colors, easeInOut, fonts, hash, ramp} from '../styles/theme';

/** Bedside digital clock that races from `from` to `to` (minutes after midnight) between frames start..end. */
export const DigitalClock: React.FC<{from: number; to: number; start: number; end: number; scale?: number}> = ({
  from,
  to,
  start,
  end,
  scale = 1,
}) => {
  const frame = useCurrentFrame();
  const t = ramp(frame, start, end, 0, 1, easeInOut);
  const mins = Math.round(from + (to - from) * t);
  const hh = Math.floor(mins / 60) % 12 || 12;
  const mm = mins % 60;
  const done = frame >= end;
  const flick = !done && hash(frame * 2.3) > 0.7 ? 0.65 : 1;
  const pulse = done ? 0.78 + 0.22 * Math.sin((frame - end) * 0.6) : 1;
  const color = done ? colors.red : colors.ice;
  const glow = done ? 'rgba(225,29,46,0.85)' : 'rgba(111,168,220,0.6)';
  const colon = done || Math.floor(frame / 8) % 2 === 0 ? 1 : 0.15;
  const pad = (n: number) => String(n).padStart(2, '0');
  return (
    <div
      style={{
        display: 'inline-flex',
        alignItems: 'baseline',
        gap: 18,
        padding: '22px 40px',
        background: '#050709',
        border: '4px solid #1b2028',
        borderRadius: 18,
        boxShadow: `0 0 60px ${glow}, inset 0 0 40px rgba(0,0,0,0.9)`,
        fontFamily: fonts.digital,
        fontWeight: 900,
        color,
        opacity: flick * pulse,
        transform: `scale(${scale})`,
        direction: 'ltr',
      }}
    >
      <span style={{fontSize: 140, textShadow: `0 0 24px ${glow}`}}>
        {pad(hh)}
        <span style={{opacity: colon}}>:</span>
        {pad(mm)}
      </span>
      <span style={{fontSize: 46}}>AM</span>
    </div>
  );
};
