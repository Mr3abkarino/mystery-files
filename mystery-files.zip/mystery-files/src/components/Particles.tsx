import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, W, hash} from '../styles/theme';

/** Atmospheric dust motes. Fully deterministic. */
export const Particles: React.FC<{
  count?: number;
  color?: string;
  speed?: number;
  opacity?: number;
  seed?: number;
}> = ({count = 60, color = '#cfe6ff', speed = 0.8, opacity = 0.6, seed = 0}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none', overflow: 'hidden'}}>
      {Array.from({length: count}).map((_, i) => {
        const r1 = hash(i * 3.1 + seed);
        const r2 = hash(i * 7.7 + seed + 1);
        const r3 = hash(i * 5.3 + seed + 2);
        const r4 = hash(i * 9.1 + seed + 3);
        const size = 2 + r3 * 7;
        const x = r1 * W + Math.sin(frame * 0.02 * (0.5 + r4) + i) * 40;
        const y = (((r2 * H - frame * speed * (0.3 + r3)) % H) + H) % H;
        const tw = 0.4 + 0.6 * Math.abs(Math.sin(frame * 0.04 + i));
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x,
              top: y,
              width: size,
              height: size,
              borderRadius: '50%',
              background: color,
              opacity: opacity * tw * (0.3 + r4 * 0.7),
              filter: `blur(${r3 * 3}px)`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/** Volumetric fog: large blurred gradients drifting slowly. */
export const Fog: React.FC<{color?: string; opacity?: number}> = ({color = 'rgba(80,120,180,0.35)', opacity = 0.6}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none', overflow: 'hidden', opacity}}>
      {Array.from({length: 5}).map((_, i) => {
        const x = hash(i) * W - 450 + Math.sin(frame * 0.01 + i * 2) * 220;
        const y = 250 + i * 330 + Math.cos(frame * 0.008 + i) * 80;
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x,
              top: y,
              width: 900,
              height: 600,
              background: `radial-gradient(ellipse at center, ${color} 0%, rgba(0,0,0,0) 70%)`,
              filter: 'blur(40px)',
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};
