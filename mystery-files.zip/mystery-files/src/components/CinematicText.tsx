import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {colors, fonts, hash, ramp, TEXT_Y, W} from '../styles/theme';

export type TextLine = {
  text: string;
  start: number; // scene-local frame
  end?: number; // scene-local frame (fade-out); omit to stay
  size?: number;
  color?: string;
  glow?: string;
  glitch?: boolean;
  wordDelay?: number;
};

/**
 * ARABIC NOTE: text is animated WORD by WORD, never letter by letter.
 * Splitting Arabic into per-letter elements breaks contextual joining (shaping),
 * so each word stays one intact text node. The container is dir="rtl", so the
 * first word is rendered at the right, which is the correct reading order.
 * No letter-spacing is applied to Arabic (it also breaks joining).
 */
const Line: React.FC<{spec: TextLine; absolute: boolean}> = ({spec, absolute}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const size = spec.size ?? 120;
  const color = spec.color ?? colors.bone;
  const glow = spec.glow ?? 'rgba(120,170,230,0.55)';
  const words = spec.text.split(' ').filter((w) => w.length > 0);
  const wordDelay = spec.wordDelay ?? 4;
  const exit = spec.end !== undefined ? ramp(frame, spec.end, spec.end + 8, 1, 0) : 1;
  const breathe = ramp(frame, spec.start, spec.start + 120, 1, 1.06);

  return (
    <div
      dir="rtl"
      lang="ar"
      style={{
        position: absolute ? 'absolute' : 'relative',
        left: 0,
        right: 0,
        top: absolute ? 0 : undefined,
        bottom: absolute ? 0 : undefined,
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'center',
        alignItems: 'center',
        direction: 'rtl',
        columnGap: size * 0.24,
        fontFamily: fonts.arabic,
        fontWeight: 900,
        fontSize: size,
        lineHeight: 1.3,
        color,
        textAlign: 'center',
        opacity: exit,
        transform: `scale(${breathe})`,
      }}
    >
      {words.map((w, i) => {
        const f = frame - spec.start - i * wordDelay;
        const p = spring({frame: Math.max(0, f), fps, config: {damping: 13, stiffness: 140, mass: 0.7}});
        const op = ramp(f, 0, 5, 0, 1);
        const blur = ramp(f, 0, 9, 16, 0);
        const g = spec.glitch === true && f > 0 && f < 40 && hash(frame * 1.7 + i) > 0.82;
        const dx = g ? 6 + hash(frame + i) * 14 : 0;
        const shadow = g
          ? `${dx}px 0 rgba(255,30,70,0.9), ${-dx}px 0 rgba(0,200,255,0.8)`
          : `0 0 40px ${glow}, 0 6px 30px rgba(0,0,0,0.95)`;
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              opacity: op,
              transform: `translateY(${(1 - p) * 70}px) scale(${1.5 - 0.5 * p}) skewX(${g ? (hash(frame) - 0.5) * 16 : 0}deg)`,
              filter: `blur(${blur}px)`,
              textShadow: shadow,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

export const CinematicText: React.FC<{
  lines: TextLine[];
  top?: number;
  /** 'stack': lines flow top to bottom. 'replace': lines share one slot (use when they appear one after another). */
  mode?: 'stack' | 'replace';
  height?: number;
}> = ({lines, top = TEXT_Y, mode = 'stack', height = 300}) => (
  <div
    dir="rtl"
    lang="ar"
    style={{
      position: 'absolute',
      left: 60,
      width: W - 120,
      top,
      height: mode === 'replace' ? height : undefined,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
    }}
  >
    {lines.map((l, i) => (
      <Line key={i} spec={l} absolute={mode === 'replace'} />
    ))}
  </div>
);
