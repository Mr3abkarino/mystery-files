import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Scene01} from './scenes/Scene01';
import {Scene02} from './scenes/Scene02';
import {Scene03} from './scenes/Scene03';
import {Scene04} from './scenes/Scene04';
import {Scene05} from './scenes/Scene05';
import {Scene06} from './scenes/Scene06';
import {FilmGrain} from './components/FilmGrain';
import {ColorGrade, EdgeBlur, Vignette} from './components/Overlays';
import {CUES} from './audioCues';
import {colors, fonts, ramp, SCENES, TOTAL, W} from './styles/theme';

const AudioTrack: React.FC = () => (
  <>
    {CUES.map((c) => {
      const dur = c.durationInFrames ?? TOTAL - c.from;
      return (
        <Sequence key={c.id} from={c.from} durationInFrames={dur} layout="none">
          <Audio
            src={staticFile(`audio/${c.file}`)}
            loop={c.loop}
            volume={(f: number) => {
              const base = typeof c.volume === 'function' ? c.volume(f) : c.volume;
              const fi = c.fadeIn ? ramp(f, 0, c.fadeIn, 0, 1) : ramp(f, 0, 1, 0, 1);
              const fo = ramp(f, dur - (c.fadeOut ?? 2), dur, 1, 0);
              return Math.max(0, Math.min(1, base * fi * fo));
            }}
          />
        </Sequence>
      );
    })}
  </>
);

/** Persistent label: this is fiction, not a real case. */
const FictionTag: React.FC = () => {
  const frame = useCurrentFrame();
  const opacity = ramp(frame, 12, 30, 0, 1) * ramp(frame, 884, 898, 1, 0);
  return (
    <div style={{position: 'absolute', top: 96, left: 0, width: W, display: 'flex', justifyContent: 'center', opacity}}>
      <div
        dir="rtl"
        lang="ar"
        style={{
          fontFamily: fonts.arabic,
          fontWeight: 800,
          fontSize: 30,
          color: 'rgba(230,226,214,0.8)',
          padding: '6px 22px',
          border: '1.5px solid rgba(230,226,214,0.35)',
          borderRadius: 40,
          background: 'rgba(0,0,0,0.4)',
        }}
      >
        قصة خيالية — أي تشابه مع الواقع غير مقصود
      </div>
    </div>
  );
};

export const MysteryEpisode: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: colors.black}}>
    <Sequence from={SCENES.s1.from} durationInFrames={SCENES.s1.dur}>
      <Scene01 />
    </Sequence>
    <Sequence from={SCENES.s2.from} durationInFrames={SCENES.s2.dur}>
      <Scene02 />
    </Sequence>
    <Sequence from={SCENES.s3.from} durationInFrames={SCENES.s3.dur}>
      <Scene03 />
    </Sequence>
    <Sequence from={SCENES.s4.from} durationInFrames={SCENES.s4.dur}>
      <Scene04 />
    </Sequence>
    <Sequence from={SCENES.s5.from} durationInFrames={SCENES.s5.dur}>
      <Scene05 />
    </Sequence>
    <Sequence from={SCENES.s6.from} durationInFrames={SCENES.s6.dur}>
      <Scene06 />
    </Sequence>

    {/* global look: depth-of-field edges, colour grade, vignette, film grain */}
    <EdgeBlur />
    <ColorGrade />
    <Vignette />
    <FilmGrain opacity={0.2} />
    <FictionTag />
    <AudioTrack />
  </AbsoluteFill>
);
