#!/usr/bin/env bash
# Synthesises ORIGINAL, royalty-free placeholder sound design with ffmpeg (48 kHz stereo WAV).
# Replace any file in public/audio/ with your own asset of the same name to upgrade the mix.
set -euo pipefail
OUT="$(cd "$(dirname "$0")/.." && pwd)/public/audio"
mkdir -p "$OUT"
SR=48000

# syn <name> <seconds> <aevalsrc-expression> [audio filter chain]
syn() {
  if [ -n "${4:-}" ]; then
    ffmpeg -y -loglevel error -f lavfi -i "aevalsrc='$3':s=$SR:d=$2" -af "$4" -ac 2 -ar $SR -c:a pcm_s16le "$OUT/$1.wav"
  else
    ffmpeg -y -loglevel error -f lavfi -i "aevalsrc='$3':s=$SR:d=$2" -ac 2 -ar $SR -c:a pcm_s16le "$OUT/$1.wav"
  fi
}

# Dark ambient drone (30 s)
syn ambient 30 "0.5*sin(2*PI*55*t)+0.3*sin(2*PI*82.4*t+sin(2*PI*0.1*t)*2)+0.2*sin(2*PI*110.7*t)*(0.5+0.5*sin(2*PI*0.07*t))+0.06*(random(0)*2-1)" \
  "lowpass=f=700,volume=0.8,afade=t=in:d=2,afade=t=out:st=27:d=3"

# Deep sub-bass impact
syn impact 3.5 "0.95*sin(2*PI*(38+90*exp(-10*t))*t)*exp(-1.6*t)+0.25*(random(0)*2-1)*exp(-30*t)" \
  "lowpass=f=3000,alimiter=limit=0.95"

# Metallic door clang
syn metal 2 "0.22*(sin(2*PI*610*t)+0.8*sin(2*PI*1097*t)+0.6*sin(2*PI*1763*t)+0.5*sin(2*PI*2711*t)+0.3*sin(2*PI*4021*t))*exp(-5*t)+0.3*(random(0)*2-1)*exp(-60*t)" \
  "aecho=0.6:0.5:60|130:0.35|0.2,volume=10dB,alimiter=limit=0.95"

# Old telephone bell (ring burst 1.4 s, pause 1.0 s)
syn phone_ring 6 "0.35*lt(mod(t,2.4),1.4)*(0.55+0.45*sin(2*PI*24*t))*(sin(2*PI*1240*t)+0.7*sin(2*PI*1630*t))" \
  "aecho=0.5:0.4:80:0.25,volume=11dB,alimiter=limit=0.95"

# Clock tick-tock (6 s, loopable)
syn tick 6 "(random(0)*2-1)*exp(-mod(t,1)*90)*0.9*(1+0.3*lt(mod(t,2),1))" \
  "highpass=f=800,lowpass=f=6000,volume=0.9"

# Reverse whoosh (noise riser)
syn whoosh_rev 1.5 "(random(0)*2-1)*pow(t/1.5,3)*0.9" \
  "bandpass=f=1800:width_type=h:w=2500,afade=t=out:st=1.44:d=0.06"

# Security-camera static
syn static 3 "(random(0)*2-1)*(0.6+0.4*sin(2*PI*13*t))*0.5" \
  "highpass=f=1500"

# Footsteps in an empty corridor (5 s)
syn footsteps 5 "(0.9*(random(0)*2-1)*exp(-mod(t,0.62)*34)+0.7*sin(2*PI*85*t)*exp(-mod(t,0.62)*22))*0.7" \
  "lowpass=f=900,aecho=0.6:0.5:120|240:0.3|0.2,volume=9dB,alimiter=limit=0.95"

echo "Audio written to $OUT"
